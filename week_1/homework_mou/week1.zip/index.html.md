<html>
<head>
	<title>Joe Johnson Developer</title>
	<link rel="stylesheet" type="text/css" href="./style.css.md">
</head>
<body>
	<div id="nav">
		<ul>
			<li class="nav italic" >About Me</li>
			<li class="nav"><a href="./portfolio.html.md">Portfolio</a></li>
		</ul>
	</div>
	<h1>Joe Johnston</h1>
	<div id="main">
	<hr>
	<h2>I enjoy life as a developer</h2>
	<p id="info">I'm Joe Johnson, a Developer based in NYC. I Have ten years of experience in the graphic design world, specializing in the creation of responsive websites.</p>
	<img id="profile" src="./images/profile.jpg" alt="image of gin hodge">
	<hr>
	</div>
	<p id="socialbar"><a class="social" href="https://www.facebook.com/gin.hodge">Facebook</a> | <a class="social" href="https://twitter.com/GinHodge">Twitter</a> | <a class="social" href="https://www.instagram.com/gin.hodge/?hl=en">Instagram</a> | <a class="social" href="https://www.linkedin.com/in/virginiahodge/">Linkedin</a></p>
</body>
</html>