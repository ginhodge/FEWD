body {
	font-family: sans-serif;
	background-color: cornsilk;
	font-size: 18px;
}

h1 {
	text-align: center;
	font-size: 26px;
}

.nav {
	display: inline;
	text-align: center;

}

#nav {
	text-align: center;
}

h2 {
	text-align: left;
	font-size: 22px;
}

#main {
	width: 800px;
	margin: auto;
}

#info {
	font-family: serif;
	width: 400px;
	text-align: left;
	float: left;
}

p {
	text-align: left;
	font-family: serif;
}

.cv {
	text-align: left;
}

#profile {
	padding: 30px 0px;

}

.portfoliopic {
	margin: 20px auto;
}

hr {
	clear: both;
}

a {
	color: black;
}

a:hover {
	color: pink;
}

#socialbar {
	text-align: center;
	font-family: sans-serif;
	font-weight: bold;
}

.bold {
	font-weight: bold;
	font-style: italic;
}

.italic {
	font-style: italic;
}